z3c.checkversions
=================

Find newer versions of your installed Python packages, or newer versions of
packages specified in a buildout.

This package provides a console script named ``checkversions``.

